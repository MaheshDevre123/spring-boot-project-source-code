package com.fourserveglobal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToOneMappingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
